package com.cg.hostel.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.hostel.bean.CustomerBean;
import com.cg.hostel.bean.HostelBean;
import com.cg.hostel.exception.CustomerException;
import com.cg.hostel.exception.HostelException;
import com.cg.hostel.util.DBConnection;

public class CustomerDaoImpl implements CustomerDao{
	Logger logger=Logger.getRootLogger();
	public CustomerDaoImpl()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}
	@Override
	public List viewHostel() throws CustomerException {
		Connection con=DBConnection.getConnection();
		int hostelCount=0;
		PreparedStatement ps=null;
		ResultSet resultset = null;
		List<HostelBean> hostelList=new ArrayList<HostelBean>();
		try
		{
			ps=con.prepareStatement(QueryMapper.view_hostel);
			resultset=ps.executeQuery();
			while(resultset.next())
			{
				HostelBean hostelBean=new HostelBean();
				hostelBean.setNestId(resultset.getString(1));
				hostelBean.setNestName(resultset.getString(2));
				hostelBean.setNestLocation(resultset.getString(3));
				hostelBean.setPhoneNumber(resultset.getString(4));
				hostelBean.setRent(resultset.getInt(5));
				hostelList.add(hostelBean);
				hostelCount++;
				
			}
			
		}
		catch(Exception e)
		{
			e.fillInStackTrace();
		}
		finally
		{
			try
			{
				resultset.close();
				ps.close();
				con.close();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		if(hostelCount==0)
			return null;
		else
			return hostelList;
	
	}

	@Override
	public String addCustomer(CustomerBean customer) throws CustomerException {
		Connection connection=com.cg.hostel.util.DBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		String room_Number=null;
		int queryResult=0;
		try
		{
			preparedStatement=connection.prepareStatement(QueryMapper.insert_customer);
			preparedStatement.setString(1, customer.getCustomerName());
			preparedStatement.setString(2, customer.getPhoneNumber());
			preparedStatement.setString(3, customer.getAddress());
			preparedStatement.setString(4, customer.getGraudianName());
			queryResult=preparedStatement.executeUpdate();
			//Statement statement=null;
			//statement=connection.createStatement();
			//resultSet=statement.executeQuery("select max(roomNumber) from cust_details");
			preparedStatement=connection.prepareStatement(QueryMapper.get_max_roomNumber);
			//preparedStatement.setString(1,room_Number);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				room_Number=resultSet.getString(1);
			}
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new CustomerException("Inserting customer details failed ");

			}
			else
			{
				logger.info("customer details added successfully:");
				return room_Number;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.error(e.getMessage());
			throw new CustomerException("Tehnical problem occured refer log");
			
		}
		finally
		{
			
		
		try {
			preparedStatement.close();
			connection.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.error(e.getMessage());
			throw new CustomerException("Error in closing db connection");

		}
		}
		
	}

	@Override
	public CustomerBean viewCustomerDetails(String roomNumber) throws CustomerException, SQLException {
		Connection connection=DBConnection.getConnection();
		ResultSet resultSet=null;
		PreparedStatement preparedStatement=null;
		//Statement st=null;
		try
		{
		CustomerBean customerBean=new CustomerBean();
		//st=connection.createStatement();
		//resultSet=st.executeQuery("select * from cust_details where roomNumber="+roomNumber+"");
		
		preparedStatement=connection.prepareStatement(QueryMapper.retrieve_customer);
		preparedStatement.setString(1,roomNumber);
		resultSet=preparedStatement.executeQuery();
		while(resultSet.next())
		{
			customerBean.setRoomNumber(resultSet.getString(1));
			customerBean.setCustomerName(resultSet.getString(2));
			customerBean.setPhoneNumber(resultSet.getString(3));
			customerBean.setAddress(resultSet.getString(4));
			customerBean.setGraudianName(resultSet.getString(5));
			customerBean.setJoiningDate(resultSet.getDate(6));
			
		}
		if( customerBean != null)
		{
			logger.info("Record Found Successfully");
			return customerBean;
		}
		else
		{
			logger.info("Record Not Found Successfully");
			return null;
		}
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
			throw new CustomerException(e.getMessage());
		}
		finally
		{
			try 
			{
				resultSet.close();
				connection.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new CustomerException("Error in closing db connection");

			}
		}
		
		
		
	}

	@Override
	public List retrieveAll() throws CustomerException {
		Connection con=DBConnection.getConnection();
		int customerCount=0;
		PreparedStatement ps=null;
		ResultSet resultset = null;
		List<CustomerBean> customerList=new ArrayList<CustomerBean>();
		try
		{
			ps=con.prepareStatement(QueryMapper.list_all_customer);
			resultset=ps.executeQuery();
			while(resultset.next())
			{
				CustomerBean customerBean=new CustomerBean();
				customerBean.setRoomNumber(resultset.getString(1));
				customerBean.setCustomerName(resultset.getString(2));
				customerBean.setPhoneNumber(resultset.getString(3));
				customerBean.setAddress(resultset.getString(4));
				customerBean.setGraudianName(resultset.getString(5));
				customerBean.setJoiningDate(resultset.getDate(6));
				customerList.add(customerBean);
				customerCount++;
			}
			
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
			throw new CustomerException("Tehnical problem occured. Refer log");
		}
		finally
		{
			try
			{
				resultset.close();
				ps.close();
				con.close();
			}
			catch(Exception e)
			{
				logger.error(e.getMessage());
				throw new CustomerException("Error in closing db connection");
			}
		}
		if(customerCount==0)
			return null;
		else
			return customerList;
	}

	@Override
	public String registerHostel(HostelBean hostel) throws HostelException {
		Connection connection=com.cg.hostel.util.DBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		String nest_Id=null;
		int queryResult=0;
		try
		{
			preparedStatement=connection.prepareStatement(QueryMapper.add_hostel);
			preparedStatement.setString(1, hostel.getNestName());
			preparedStatement.setString(2, hostel.getNestLocation());
			preparedStatement.setString(3, hostel.getPhoneNumber());
			preparedStatement.setInt(4, hostel.getRent());
			preparedStatement.executeUpdate();
			//Statement statement=null;
			//statement=connection.createStatement();
			//resultSet=statement.executeQuery("select max(nestid) from nest_details");
			preparedStatement=connection.prepareStatement(QueryMapper.get_max_nestId);
			//preparedStatement.setString(1,nest_Id);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				nest_Id=resultSet.getString(1);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		try {
			resultSet.close();
			preparedStatement.close();
			connection.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return nest_Id;
		
		
	}

	
	@Override
	public HostelBean getHostelName(String allocate) throws HostelException, SQLException {
		Connection connection=DBConnection.getConnection();
		ResultSet resultSet=null;
		PreparedStatement preparedStatement=null;
		//Statement st=null;
		HostelBean hostelBean=new HostelBean();
		//st=connection.createStatement();
		//resultSet=st.executeQuery("select * from nest_details where nestId="+allocate+"");
		preparedStatement=connection.prepareStatement(QueryMapper.get_hostel_name);
		preparedStatement.setString(1,allocate);
		resultSet=preparedStatement.executeQuery();
		while(resultSet.next())
		{
			hostelBean.setNestId(resultSet.getString(1));
			hostelBean.setNestName(resultSet.getString(2));
			hostelBean.setNestLocation(resultSet.getString(3));
			hostelBean.setPhoneNumber(resultSet.getString(4));
			hostelBean.setRent(resultSet.getInt(5));
			
			
		}
		return hostelBean;
		
	}

		
	}


