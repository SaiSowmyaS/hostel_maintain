package com.cg.hostel.exception;

public class HostelException extends Exception {

	public HostelException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public HostelException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public HostelException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public HostelException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public HostelException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	

}
