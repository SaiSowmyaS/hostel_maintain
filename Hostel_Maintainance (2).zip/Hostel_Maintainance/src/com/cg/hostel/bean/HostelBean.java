package com.cg.hostel.bean;

public class HostelBean {    
	private String nestId;                  //variables that admin uses to store the data
	private String nestName;
	private String nestLocation;
	private String phoneNumber;
	private int rent;
	public String getNestId() {
		return nestId;
	}
	public void setNestId(String nestId) {
		this.nestId = nestId;
	}
	public String getNestName() {
		return nestName;
	}
	public void setNestName(String nestName) {
		this.nestName = nestName;
	}
	public String getNestLocation() {
		return nestLocation;
	}
	public void setNestLocation(String nestLocation) {
		this.nestLocation = nestLocation;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public int getRent() {
		return rent;
	}
	public void setRent(int rent) {
		this.rent = rent;
	}
	//to display the hostel details
	@Override
	public String toString() {
		return "HostelBean [nestId=" + nestId + ", nestName=" + nestName + ", nestLocation=" + nestLocation
				+ ", phoneNumber=" + phoneNumber + ", rent=" + rent + "]";
	}
	

}
